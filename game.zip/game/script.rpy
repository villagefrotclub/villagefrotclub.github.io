﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("tester")

# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bg room

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    show tester
    with Dissolve(.5)

    # These display lines of dialogue.

    e "You've created a new Ren'Py game."

    e "Holy shit."
    
    menu:
        "i like number 1":
            # Statements to run if Choice 1 is selected (e.g., jump, say)
            $ num = 1
        
        "i like number 2":
            # Statements for Choice 2
            $ num = 2
        
        "i like number 3":
            # Statements for Choice 3
            $ num = 3
    
    e "I HATE [num]. You suck."
    e "Goodbye."
    
    hide tester
    with Dissolve(.5)

    # This ends the game.

    return
